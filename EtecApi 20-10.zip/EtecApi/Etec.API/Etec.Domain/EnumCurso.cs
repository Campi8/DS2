﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Etec.Domain
{
    public enum EnumCurso
    {
        Mecanica = 10,
        DesenvolvimentoSistema = 20,
        Mecatronica = 30,
        Eletrotecnica = 40,
        Administracao = 50,
        Enfermagem = 60,
        Turismo = 70
    }
}
