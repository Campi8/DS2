﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

//FluentAPI

namespace Etec.Domain
{
    [Table("TB_Aluno")]
    public class Aluno
    {
        [Key]
        [Required(ErrorMessage = "Id é de Preenchimento Obrigatório")]
        public int Id { get; set; }

        [MaxLength(100, ErrorMessage = "O nome deve ter no máximo 100 caracteres")]        
        [Required(ErrorMessage = "Nome é de Preenchimento Obrigatório")]
        public string Nome { get; set; }
        
        [MaxLength(20, ErrorMessage = "O apelido deve ter no máximo 20 caracteres")]
        public string Apelido { get; set; }

        [Required(ErrorMessage = "Data de Nascimento é de Preenchimento Obrigatório")]
        public DateTime DataNascimento { get; set; }

        [Required(ErrorMessage = "Curso é de Preenchimento Obrigatório")]
        public EnumCurso Curso { get; set; }
    }
}
