﻿using Etec.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Etec.API.Context
{
    public class EtecContext: DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            var connection = "server=localhost;port=3306;database=etec;uid=root"; //;password=S_E_N_H_A

            optionsBuilder.UseMySql(
                connection,
                ServerVersion.AutoDetect(connection));

            
        }

        public DbSet<Aluno> AlunoSet { get; set; }
    }
}
