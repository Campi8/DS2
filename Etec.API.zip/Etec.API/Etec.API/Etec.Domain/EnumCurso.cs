﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Etec.Domain
{
    public enum EnumCurso
    {
        //Mecanica = 10 seta o valor para 10
        Mecanica,
        DesenvolvimentoSistemas,
        Mecatronica,
        Eletrotecnica,
        Administracao,
        Enfermagem,
        Turismo

        
    }
}
